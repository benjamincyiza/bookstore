-- FUNCTION: public.stores()

-- DROP FUNCTION public.stores();

CREATE FUNCTION public.stores()
    RETURNS trigger
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE NOT LEAKPROOF
AS $BODY$
begin
if NEW.quantity<10 then
	update supplies set quantity=quantity+10;
	update stores set quantity=quantity+10;
end if;
return new;
end;
$BODY$;

ALTER FUNCTION public.stores()
    OWNER TO postgres;

create trigger q_check
before update
on stores
for each row
execute procedure stores();

