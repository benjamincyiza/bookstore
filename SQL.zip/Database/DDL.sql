create table book(
	bookId varchar(5) NOT NULL ,
	title varchar (30),
	price numeric(9,1),
	genre varchar (500),
	pages numeric(5,1) check (pages>0),
	published date,
	ISBN varchar(13),
	primary key (bookId)
);

create table author(
	authorId varchar(5) NOT NULL ,
	name varchar(20),
	email varchar(25),
	primary key (authorId)
);

create table book_order(
	orderId varchar(25) NOT NULL ,
	primary key (orderId)
);

create table customer(
	username varchar(25) NOT NULL ,
	name varchar(25),
	password varchar(8),
	address varchar(30),	
	primary key (username)	
);

create table shipping_company(
	shipId varchar(5) NOT NULL ,
	name varchar(25),
	primary key (shipId)
);

create table publisher(
	pubId varchar(5) primary key NOT NULL,
	name varchar(50),
	bookId varchar(5) ,
	foreign key (bookid) references book 
		on delete cascade 
);

create table bookstore (
	storeId varchar(5) primary key NOT NULL ,
	name varchar(50) ,
	password varchar(8),
	username varchar(25)	
);

create table sales(
	storeId varchar(5),
	username varchar(25),
	bookId varchar(5),
	quantity numeric(8,1) check (quantity>0),
	foreign key (storeId) references bookstore
		on delete cascade,
	foreign key (username) references customer
		on delete cascade,
	foreign key (bookId) references book
		on delete cascade
	
);

create table supplies (
	pubId varchar(5),
	storeid varchar(5),
	bookId varchar(5),
	quantity numeric(8,1) check (quantity>0),
	primary key (pubId, storeId),
	foreign key (pubId) references publisher
		on delete cascade,
	foreign key (storeId) references bookstore
		on delete cascade,
	foreign key (bookId) references book
		on delete cascade
);

create table writes (
	authorId varchar(5),
	bookId varchar(5),
	foreign key (authorId) references author
		on delete cascade,
	foreign key (bookId) references book
		on delete cascade
);

create table customer_order(
	username varchar(25),
	orderId varchar(25),
	primary key(username, orderId),
	foreign key (username) references customer
		on delete cascade,
	foreign key (orderId) references book_order
		on delete cascade
);

create table stores(
	storeId varchar(5),
	bookId varchar(5),	
	quantity numeric(8,1),
	primary key( bookId, storeId),
	foreign key (bookId) references book
		on delete cascade,
	foreign key (storeId) references bookstore
		on delete cascade
);

create table contains(
	bookid varchar(5),
	orderid varchar(25),
	foreign key (bookid) references book
	on delete cascade,
	
	foreign key (orderid) references book_order
	on delete cascade
	
);

create table prepares(
	storeid varchar(5),
	orderid varchar(25),
	primary key(storeid, orderid),
	foreign key (storeid) references bookstore
		on delete cascade,
	foreign key (orderid) references book_order
		on delete cascade
);

create table ship_order(
	shipId varchar(5),
	orderid varchar(25),
	primary key(shipId, orderid),
	foreign key (shipId) references shipping_company
		on delete cascade,
	foreign key (orderid) references book_order
		on delete cascade
);

create table commands(
	username varchar(25),
	orderid varchar(25),
	primary key(username, orderid),
	foreign key (username) references customer
		on delete cascade,
	foreign key (orderid) references book_order
		on delete cascade
);

create table delivers(
	username varchar(25),
	shipId varchar(5),
	orderId varchar(25),
	foreign key (orderid) references book_order
		on delete cascade,
	foreign key (username) references customer
		on delete cascade,
	foreign key (shipId) references shipping_company
		on delete cascade
	
);

