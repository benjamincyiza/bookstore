insert into book 
values ('b0001','will',50,'action and edventure',432,'2021-11-09','9781984877925');
insert into book 
values ('b0002','A Promised Land',50,'action and edventure',768,'2020-11-17','9781524763169');

insert into book 
values ('b0003','The Purpose Driven Life',50,'action and edventure',368,'2013-12-31','9780310337508');

insert into book 
values ('b0004','Crossroads',50,'action and edventure',296,'2021-03-16','9781443462877');

insert into book 
values ('b0005','Home Body',50,'action and edventure',208,'2021-12-07','9781501175299');

insert into publisher 
values ('p0001','Penguin Publishing Group','b0001');

insert into publisher 
values ('p0002','Crown','b0002');

insert into publisher 
values ('p0003','Zondervan','b0003');

insert into publisher 
values ('p0004','HarperCollins','b0004');

insert into publisher 
values ('p0005','Simon & Schuster','b0005');

insert into author
values ('a0002','will smith','will@gmail.com');
insert into author
values ('a0003','Rick warren' , 'rick01@gmail.com');

insert into author
values ('a0004','Kaleb Dahlgren' , 'dahlgren1@gmail.com');

insert into author
values ('a0005','Rupi Kaur' , 'rupi@gmail.com');

insert into writes
values('a0001','b0002');

insert into writes
values('a0002','b0001');

insert into writes
values('a0003','b0003');

insert into writes
values('a0004','b0004');

insert into writes
values('a0005','b0005');

insert into bookstore
values ('bs01','ben bookstore', 'pass', 'benbook');

insert into supplies 
	select pubid,'bs01',bookid,10
	from publisher;

insert into stores 
	select 'bs01',bookid,10
	from book;

insert into shipping_company values ('shi01','pop');

