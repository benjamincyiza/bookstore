const http =require('http')
const fs=require('fs')

const serve=http.createServer(function(req,res){
	if(req.method==='Get'){
		if(req.url==='/' || req.url==='/index.html'){
			fs.readFile('src/index.html',function(err,data){
				if(err){
					res.statusCode=500;
					res.end()
				}
				else{
					res.statusCode=200;
					res.setHeader('content-type','text/html')
					res.write(data)
					res.end()
				}
			})
		}
	}
})

serve.listen(3000)

console.log("localhost:3000")
