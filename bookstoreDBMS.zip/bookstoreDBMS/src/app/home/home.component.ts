import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { LogicService } from '../logic.service'

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  searched="";
  selected="title";
  todisplay: object;
  books: object;
  constructor(private http:HttpClient, private logic:LogicService) { }

  ngOnInit(): void {
    this.load();
    
    
  }

  load(){
    
    let url='/api/'
    this.http.get(url).subscribe(res =>{
      if(res["error"]){
        alert(res["error"])
        return;
      }
      this.books=res['rows'];
      
    })
  }
  search(){
    let b={"type":this.selected, "search":this.searched}
    let url='/api/search';
    this.http.post(url, b ).subscribe(res =>{
      if(res["error"]){
        alert(res["error"])
        return;
      }
      this.books=res['rows'];
      
    })
    
  }
  addBook(b:object){
    console.log(b); 

    this.logic.cart.push(b);
  }

  display(b){
    this.todisplay=b;
    
  }

}
