import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { NavComponent } from './nav/nav.component';
import { HomeComponent } from './home/home.component';
import { CheckoutComponent } from './customer/checkout/checkout.component';
import { RegistrationComponent } from './customer/registration/registration.component';
import { DashboardComponent } from './staff/dashboard/dashboard.component';
import { TestComponent } from './test/test.component';
import { SigninComponent } from './staff/signin/signin.component';
import { ReportComponent } from './staff/report/report.component';


@NgModule({
  declarations: [
    AppComponent,
    NavComponent,
    HomeComponent,
    CheckoutComponent,
    RegistrationComponent,
    DashboardComponent,
    TestComponent,
    SigninComponent,
    ReportComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
