import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { LogicService } from '../../logic.service'

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.scss']
})
export class SigninComponent implements OnInit {
  userName="";
  password="";
  constructor(private logic:LogicService,private http:HttpClient,private router: Router,private route: ActivatedRoute) { }

  ngOnInit(): void {    
    
    if(this.logic.staff!=null){
      this.router.navigate(['/dashboard'])
    }
  }


  signIn(){
    let body={"table":"bookstore", "username":this.userName.toLowerCase(),"password":this.password}
    
    if(this.userName.length==0 || this.password.length==0){
      alert("please enter your username and password");
    }
    let url="/api/signIn";
    this.http.post(url,body).subscribe(res =>{
      if(res["error"]){
        alert (res["error"])
        return;
      }  
      console.log(res["rows"].length);
          
      if(res["rows"].length<=0){
        alert("username or passowrd is incorect")
        return;
      }
      this.logic.staff=res['rows'];
      this.logic.signed=new Object;
      this.router.navigate(['/dashboard'])
    })
  }
}
