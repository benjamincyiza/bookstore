import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Component({
  selector: 'app-report',
  templateUrl: './report.component.html',
  styleUrls: ['./report.component.scss']
})
export class ReportComponent implements OnInit {
  sold: object;
  bought: object;
  totalp: number;
  authP: number;
  supP: number;
  bookP: number;
  constructor(private http:HttpClient) { }

  ngOnInit(): void {
    this.sales();
    this.purchases();    
    this.profit();
  }

  sales(){
    let url="/api/sales"
    this.http.get(url).subscribe(res =>{
      if(res["error"]){
        alert(res["error"])
      }
      this.sold=res;
    })
    
  }

  purchases(){
    let url="/api/purchases"
    this.http.get(url).subscribe(res =>{
      if(res["error"]){
        alert(res["error"])
      }
      this.bought=res;
    })
  }

  profit(){
    let url="/api/profit"
    this.http.get(url).subscribe(res =>{
      if(res["error"]){
        alert(res["error"])
      }
      this.totalp=res[0]['sum']
      this.authP=this.totalp*0.25;
      this.supP=this.totalp*0.25;
      this.bookP=this.totalp*0.5;
    })
  }

}
