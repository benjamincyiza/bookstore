import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  books: object;
  todisplay: object;
  
  constructor(private http:HttpClient) { }

  ngOnInit(): void {
    this.load()
  }

  load(){
    let url='/api/stores';
    this.http.get(url).subscribe(res =>{
      if(res["error"]){
        alert(res["error"])
      }
      this.books=res;
    })
  }
  display(b){
    this.todisplay=b;
    
  }

}
