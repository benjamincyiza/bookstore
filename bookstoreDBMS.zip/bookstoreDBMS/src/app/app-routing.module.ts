import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { NavComponent } from './nav/nav.component';
import { HomeComponent } from './home/home.component';
import { CheckoutComponent } from './customer/checkout/checkout.component';
import { RegistrationComponent } from './customer/registration/registration.component';
import { DashboardComponent } from './staff/dashboard/dashboard.component';
import { SigninComponent } from './staff/signin/signin.component';
import { ReportComponent } from './staff/report/report.component';

const routes: Routes = [
  {path: '', component: HomeComponent},
  {path:'home',component:HomeComponent},
  {path: 'checkout', component: CheckoutComponent},
  {path: 'registration', component: RegistrationComponent},
  {path: 'dashboard', component: DashboardComponent},
  {path: 'signin', component:SigninComponent},
  {path: 'dashboard/report', component:ReportComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
