import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';




@Injectable({
  providedIn: 'root'
})
export class LogicService {
  signed:object;
  staff=null;
  cart=[];
  constructor(private http: HttpClient) { }
  handleError(erroType,body:object){
    return retry;
  }

  postMethods(url,body)  {
    return this.http.post(url, body, {headers:{'Content-Type': 'application/json'}})
      
  }

  
  
  
  
}
