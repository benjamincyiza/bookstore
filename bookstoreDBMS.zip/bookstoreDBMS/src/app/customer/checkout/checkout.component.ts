import { Component, OnInit } from '@angular/core';
import { HttpClient, ɵHttpInterceptingHandler } from '@angular/common/http';
import { LogicService } from '../../logic.service'
import * as internal from 'events';
@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.scss']
})
export class CheckoutComponent implements OnInit {
  address="";
  accNo:number;
  books: object;
  total=0;

  constructor(private http:HttpClient, private logic:LogicService) { }

  ngOnInit(): void {
    this.load()    

  }
  load(){
    
    this.books=this.logic.cart;
    
  }
  checkout(){
    if(!this.logic.signed){
      alert("please sign in") 
      return;    
    }
    var today = new Date();
    var date = today.getFullYear()+''+(today.getMonth()+1)+''+today.getDate();
    var time = today.getHours() + "" + today.getMinutes() + "" + today.getSeconds();
    let id=date+""+time;
    
    let b={"orderid":id,"product":this.logic.cart};

    let url="/api/order"
    
    this.http.post(url,b).subscribe(res =>{
      if(res["error"]){
        alert(res["error"])
        return;
      }
      this.command(id);
      this.product(id);
      this.storage(id);
      this.sale(id);
      this.prepares(id);
      this.shipp(id);
      this.deliver(id);
      alert("you have made the order")
    })
    
  }

  command(id){
    let url="/api/command";
    let b={"orderid":id, "username":this.logic.signed["username"]};
    this.http.post(url,b).subscribe(res =>{
      if(res["error"]){
        alert(res["error"])
        return;
      }
    })
  }

  sale(id){
    let url="/api/sale";
    let b={"orderid":id, "username":this.logic.signed["username"]};
    this.http.post(url,b).subscribe(res =>{
      if(res["error"]){
        alert(res["error"])
        return;
      }
    })
  }

  product(id){
    let url="/api/fillTheOrder"
    for (var book in  this.logic.cart){
      console.log(this.logic.cart[book]["bookid"]);
      
      let b={"orderid":id,"product":this.logic.cart[book]["bookid"]};
      this.http.post(url,b).subscribe(res =>{
        if(res["error"]){
          alert(res["error"])
          return;
        }
      })
    }
  }

  prepares(orderid){
    let url="/api/prepares"
    let b={"orderid":orderid};
    this.http.post(url,b).subscribe(res =>{
      if(res["error"]){
        alert(res["error"])
        return;
      }
    })
  }

  myAdd(){
    if(!this.logic.signed){
      alert("please sign in") 
      return;    
    }
    if(this.logic.signed["address"].length<=0){
      alert("we don't have the address on your profile\n please enter new address")
    }
    this.address=this.logic.signed["address"]
    
  }

  shipp(id){
    let url="/api/shipp";
    let b={"orderid":id};
    this.http.post(url,b).subscribe(res =>{
      if(res["error"]){
        alert(res["error"])
        return;
      }
    })
    
  }
  deliver(id){
    let url="/api/daliver";
    let b={"orderid":id, "username":this.logic.signed["username"]};
    this.http.post(url,b).subscribe(res =>{
      if(res["error"]){
        alert(res["error"])
        return;
      }
    })
  }
  
  storage(id){
    let url="/api/storage";
    for (var book in  this.logic.cart){
      let b={"orderid":id,"product":this.logic.cart[book]["bookid"]};
      this.http.post(url,b).subscribe(res =>{
        if(res["error"]){
          alert(res["error"])
          return;
        }
      })
    }
  }
  

}
