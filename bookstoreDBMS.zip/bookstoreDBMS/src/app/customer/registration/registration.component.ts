import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { LogicService } from '../../logic.service'

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.scss']
})
export class RegistrationComponent implements OnInit {
  usern="";
  pass=""
  username="";
  password="";
  name="";
  dateOfbirth: Date=new Date() ;
  address="";
  
  constructor(private logic:LogicService,private http:HttpClient,private router: Router,private route: ActivatedRoute) { }

  ngOnInit(): void {
  }
  /**
   * signing in
   */
  signIn(){
    let body={"table":"customer", "username":this.usern.toLowerCase(),"password":this.pass}
    
    if(this.usern.length==0 || this.pass.length==0){
      alert("please enter your username and password");
    }
    let url="/api/signIn";
    this.http.post(url,body).subscribe(res =>{
      if(res["error"]){
        alert (res["error"])
        return;
      }      
      if(res["rows"].length<=0){
        alert("username or passowrd is incorect")
        return;
      }
      this.logic.signed=res['rows'][0];

      this.logic.staff=null;
      this.router.navigate(['/home'])
    })
  }

  /**
   * signing up 
   * @returns 
   */
  signUp(){
    if(this.username.length==0 || this.address.length==0 ||
      this.password.length==0 || this.name.length==0){
          alert("please fill all information");
          return;
    }
    
    let body={"name":this.name,
                "address":this.address,
                "dateOfbirth":this.dateOfbirth,
                "username": this.username.toLowerCase(),
                "password": this.password
              };
    let url="/api/signUp";
    this.http.post(url,body).subscribe(res =>{
      if(res["error"]){
        alert (res["error"])
        return;
      }
      alert("user account created. You can now sign in")
    })
    this.username="";
    this.password="";
    this.name="";
    this.dateOfbirth=new Date() ;
    this.address="";
    

  }

}
