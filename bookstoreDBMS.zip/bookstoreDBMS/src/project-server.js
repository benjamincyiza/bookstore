let http =require("http")
let fs=require('fs')

const serve=http.createServer(function(request,response){
	if(request.method==='get'){
		let fileUrl
		if(request.url==="/"){
			fileUrl='/index.html'
		}else{
			fileUrl=request.url
		}
		let filePath=path.resolve('./src',fileUrl)

		fs.readFile(filePath,function(err,data){
			response.writeHead(200,{"content-type":'text/html'});
			response.write(data)
			return response.end()
		})
	}

})

serve.listen(3000)
console.log("server is running on localhost:3000")
