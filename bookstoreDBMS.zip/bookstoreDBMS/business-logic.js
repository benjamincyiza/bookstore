const movies=require("./movie-data.json")
const users=require('./users.json')
const people=require('./persorn.json')


/**
 * 
 * @param {user to be created} newUser 
 */
 function createUser(newUser){
    
    if(!users.hasOwnProperty(newUser.userName)){
        newUser["contributor"]=false;
        newUser['followers']=[]
        newUser['following']=[]
        newUser['watched-movie']=[]
        newUser['recommended-movie']=[]
        users[newUser.userName]=newUser;
        return;
    }
    return null;
}

/**
 * 
 * @param {user who is requesting} reqUser 
 * user.contributor should be true or false(according to its curent value) if that user exists in database
 */
function userChangeStatus(reqUser){
    if(users.hasOwnProperty(reqUser.userName)){
        reqUser.contributor=!reqUser.contributor;
    }
}

/**
 * 
 * @param {user who is following} reqUser 
 * @param {the user who is being followed} user 
 * adds requesting user to the user.follower if user.followe does not contain requesting user
 */

function follow(reqUser, user){
    const followers=user.followers
    const following=reqUser.following
    if(!followers.hasOwnProperty(reqUser.userName) ){
        following[user.userName]=user;
        followers[reqUser.userName]=reqUser;
        return;
    }
    return null;
}

/**
 * 
 * @param {user Name of user to be searched} userName
 * return user object ehith specified username 
 */

function getUser(userName){
    if(users.hasOwnProperty(userName)){
        return users[userName];
    }
    return null;
}
/**
 * 
 * @param {name of user } name 
 * returns all users with that name
 */
function getUsers(name){
    if(name.length===0){
        return users;
    }
    let result=[]
    for(id in users){
        let user=users[id];
        let fName=user.fname;
        let lName=user.lname;

        if(fName.includes(name) || lName.includes(name)){
            result.push(user);
        }

    }
    return result;
}

/**
 * 
 * @param {any text that might be in movie} text 
 * return all movies that have specified text in their description
 */
function searchMovie(text){
    let searchedMovie=[];
    text=text.toLowerCase()
    
    for(id in movies){
        
        let movie=movies[id];  
        title=movie['Title'].toLowerCase();
        genre=movie['Genre'].toLowerCase();
        year=movie['Year'].toLowerCase();
        
        if(title.includes(text) || genre.includes(text) || year.includes(text)){
            searchedMovie.push(movie)
        }
            
    }
    return searchedMovie;
}

/**
 * 
 * @param {user who's requesting} reqUser 
 * @param {new person to be added in database} newPerson 
 * add newPerson in database if he/she doesn't exist in database already
 */
function addPerson( reqUser,newPerson){
    if(reqUser.contributor){
        let fName=newPerson.fName;
        let lName=newPerson.lName;
        let pId=fName+lName.substring(0,3)+people.length
        if(!people.hasOwnProperty(pId)){
            newPerson['contributed-in']=[];
            people[pId]=newPerson;
            return;
        }
        return;
    }
    return;
}

/**
 * 
 * @param {user who is requesting } reqUser 
 * @param {new movie ro be added to database} newMovie
 * add newMovie to database if it has minimum requiremnt 
 */
function addMovie(reqUser,newMovie){
    if(reqUser.contributor){
        let title=newMovie.title;
        let writers=newMovie.writers;
        let actors=newMovie.actors;
        let directors=newMovie.directors;
        if(title.length>0 && writers.length>0 && actors.length>0 && directors.length>0){
            console.log(newMovie);
            movies.push=newMovie;
            return;
        }
        
        return;
    }

    
    return;
}

console.log('list of user');
console.log(users)

let userA={fname:"ben", lname:"cyiza", userName:'benC',password:'carleton'}
let userB={fname:"benjamin", lname:"cyiza", userName:'benCyiza',password:'carleton'}
createUser(userA)
createUser(userB)

console.log('list of user');
console.log(users)

follow(userA,userB)

userChangeStatus(userA)

console.log('list of user');
console.log(users)

console.log('goten user')
console.log(getUser('benC'))

console.log("getting users")
console.log(getUsers("be"))

console.log('searching movie')
console.log(searchMovie('toy'))

addPerson(userA,{'fName':'kiba', 'lName':'grace'})
console.log('persorn \n')
console.log(people)

addMovie(userA,{'title':'game', 'writers':['ben','kiba'], 'actors':['ben','kiba'],'directors':['ben','kiba']})
