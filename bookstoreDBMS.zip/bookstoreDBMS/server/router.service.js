const express=require('express');
const {Client} =require('pg');

const router=express.Router()

const client=new Client({
    host:"localhost",
    user:"postgres",
    port:5432,
    password:"student",
    database:"Bookstore"
})

client.connect();


function escapeRegex(text) {
    return text.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, "\\$&");
};

/**
 * get all books
 */
router.get('/', function(req,res,next){
    let q="select * from stores natural join book";
    client.query(q,(err,result)=>{
        if(!err){
            
            res.status(200).send(result)
        } else{
            console.log(err.message);
        }
        client.end;
    })
})

/**
 * get all books in storage
 */
router.get('/stores', function(req,res,next){    
    let q="select title, genre, pages, price, name, quantity, isbn from stores natural join (book natural"+
            " join writes natural join author)";
    client.query(q, (err,result)=>{
        
        if(!err){
            res.status(200).send(result['rows'])
        } else{
            console.log("ERROR: "+err.message);
        }
        client.end;
    })
})

/**
 * singing up
 */
router.post('/signUp', function(req,res,next){
    let q="insert into customer(username,name,password,address) values ('"
            +req.body["username"]+"','"+req.body["name"]
            +"','"+req.body["password"]+"','"+req.body["address"]+"')";

    client.query(q, (err,result)=>{
        
        if(!err){
            res.status(200).send(result['rows'])
        } else{
            console.log("ERROR: "+err.message);
        }
        client.end;
    })

})

/**
 * signing in
 */

router.post('/signIn', function(req,res,next){
    let q="select * from "+req.body["table"]+
            " where username= '"+req.body["username"]
            +"' and password= '"+req.body["password"]+"'";
    client.query(q, (err,result)=>{

        if(!err){
            res.status(200).send(result)
        } else{
            console.log("ERROR: "+err.message);            
        }
        client.end;
    })
})

router.post('/search',function(req,res,next){
    let q="select * from (stores natural join book) natural join (writes natural join author) where LOWER("
            + req.body["type"]+") LIKE '%"+escapeRegex(req.body["search"])+"%' ";
    client.query(q, (err,result)=>{

        if(!err){
            res.status(200).send(result)
        } else{
            console.log("ERROR: "+err.message);
            
        }
        client.end;
    })
})

router.post("/order", function(req,res,next){
    let q= "insert into book_order values('"+req.body["orderid"]+"')"
    client.query(q, (err,result)=>{

        if(!err){
            res.status(200).send(result)
        } else{
            console.log("ERROR: "+err.message);
            
        }
        client.end;
    })
    

})
router.post("/fillTheOrder",function(req,res,next){
    
    //console.log(req.body);
    console.log("test prod server");
    
    let q="insert into contains values('"+req.body["product"]+
        "' , '"+req.body["orderid"]+"')";
    client.query(q, (err,result)=>{

        if(!err){
            res.status(200).send(result)
        } else{
            console.log("ERROR: "+err.message);
            
        }
        client.end;
    })    
    
    
})

router.post("/prepares",function(req,res,next){
    let q="insert into prepares values ('bs01','"+
            req.body["orderid"]+"')";
    console.log(q);
    client.query(q, (err,result)=>{
        if(!err){
            res.status(200).send(result)
        } else{
            console.log("ERROR: "+err.message);
            
        }
        client.end;
    })
})

router.post("/shipp",function(req,res,next){
    let q="insert into ship_order values ('shi01','"+
            req.body["orderid"]+"')";
    console.log(q);
    client.query(q, (err,result)=>{
        if(!err){
            res.status(200).send(result)
        } else{
            console.log("ERROR: "+err.message);
            
        }
        client.end;
    })
})

router.post("/command",function(req,res,next){
    let q="insert into commands values('"+req.body["username"]+"','"+
            req.body["orderid"]+"')";
    console.log(q);
    client.query(q, (err,result)=>{
        if(!err){
            res.status(200).send(result)
        } else{
            console.log("ERROR: "+err.message);
            
        }
        client.end;
    })
})

router.post("/sale",function(req,res,next){
    let q="insert into sales (storeid, username,bookid,quantity) "+
            "select 'bs01','"+req.body["username"]+"', bookid, count(bookid) as qauntity "+
            "from contains "+
            "where orderid= '"+req.body["orderid"]+
            "' group by bookid,orderid";
    console.log(q);
    client.query(q, (err,result)=>{
        if(!err){
            res.status(200).send(result)
        } else{
            console.log("ERROR: "+err.message);
            
        }
        client.end;
    })
})

router.post("/daliver",function(req,res,next){
    let q="insert into delivers values('"+
            req.body["username"]+"', 'shi01','"+req.body["orderid"]+"')";

    console.log(q);
    client.query(q, (err,result)=>{
        if(!err){
            res.status(200).send(result)
        } else{
            console.log("ERROR: "+err.message);
            
        }
        client.end;
    })
})

router.post("/book",function(req,res,next){
    let q="select title, genre, pages, price, name, isbn from book natural join writes natural join author "+
            "where bookid = '"+req.body["bookid"]+"'";

    console.log(q);
    client.query(q, (err,result)=>{
        if(!err){
            res.status(200).send(result)
        } else{
            console.log("ERROR: "+err.message);
            
        }
        client.end;
    })
})

router.post("/storage",function(req,res,next){
    let q="update stores  set quantity= quantity-1 where bookid= '"+req.body["product"]+"'"

    console.log(q);
    client.query(q, (err,result)=>{
        if(!err){
            res.status(200).send(result)
        } else{
            console.log("ERROR: "+err.message);
            
        }
        client.end;
    })
})

router.get("/sales",function(req,res,next){
    let q="select bookid, title, price, sum(quantity) as total  from sales natural join book group by bookid, price, title"

    console.log(q);
    client.query(q, (err,result)=>{
        if(!err){
            res.status(200).send(result['rows'])
        } else{
            console.log("ERROR: "+err.message);
            
        }
        client.end;
    })
})

router.get("/purchases",function(req,res,next){
    let q="select bookid, title, price, sum(quantity) as total  from supplies natural join book group by bookid, price, title"

    console.log(q);
    client.query(q, (err,result)=>{
        if(!err){
            console.log(result['rows']);
            res.status(200).send(result['rows'])
        } else{
            console.log("ERROR: "+err.message);
            
        }
        client.end;
    })
})

router.get("/profit",function(req,res,next){
    let q="select sum(ne.profit) from (select  (price*sum(quantity)) as profit from sales natural join book group by bookid,price) as ne"

    console.log(q);
    client.query(q, (err,result)=>{
        if(!err){
            console.log(result['rows']);
            res.status(200).send(result['rows'])
        } else{
            console.log("ERROR: "+err.message);
            
        }
        client.end;
    })
})

 module.exports = router;